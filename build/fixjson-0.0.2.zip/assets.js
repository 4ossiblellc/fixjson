module.exports = {
  "vendor": {
    "js": "/assets/vendor.a6b0f0ae.js"
  },
  "admin": {
    "js": "/assets/admin.1e14aa88.chunk.js"
  },
  "client": {
    "js": "/assets/client.8fe1068a.js"
  }
};